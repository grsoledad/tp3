-- Active: 1718231563151@@127.0.0.1@3306@bazar
USE bazar;
insert into clientes (nombre, apellido, dni, tel_celular, email) values
('María', 'Gómez', '12345678', '15-1234-5678', 'maria.gomez@example.com'),
('Juan', 'Rodríguez', '87654321', '15-5678-1234', 'juan.rodriguez@example.com'),
('Sofía', 'López', '23456789', '15-9012-3456', 'sofia.lopez@example.com'),
('Carlos', 'Fernández', '98765432', '15-3456-7890', 'carlos.fernandez@example.com'),
('Laura', 'Martínez', '34567890', '15-7890-1234', 'laura.martinez@example.com'),
('Jorge', 'González', '56789012', '15-2345-6789', null),
('Valentina', 'Pérez', '89012345', '15-6789-0123', null),
('Diego', 'Silva', '45678901', '15-0123-4567', 'diego.silva@example.com'),
('Ana', 'Rojas', '90123456', '15-4567-8901', 'ana.rojas@example.com'),
('Lucas', 'Acosta', '67890123', '15-8901-2345', null);

select * from clientes;

insert into articulos (codigo, producto, stock) values
(100, 'Cacerola granito antiadherente', 157),
(101, 'Cafetera italiana', 100),
(102, 'Jarra de vidrio', 75),
(103, 'Budinera de teflon antiadherente', 120),
(104, 'Pochoclera', 127),
(105, 'Especiero giratorio', 60),
(200, 'Carro auxiliar', 53),
(201, 'Cortina de ducha impermeable con diseño', 40),
(202, 'Jabonera de cerámica blanca', 80),
(203, 'Tacho de baño', 140);

select * from articulos;

insert into facturas (letra, numero, fecha, monto, id_cliente) values
('B', 1, '2024-06-03', 125000.0, 2),
('C', 1, '2024-06-05', 165000.0, 5),
('B', 2, '2024-06-04', 260000.0, 4),
('C', 2, '2024-06-06', 78000.0, 6),
('B', 3, '2024-06-12', 285000.0, 7),
('C', 3, '2024-06-17', 198000.0, 8),
('B', 4, '2024-06-20', 155000.0, 9),
('C', 4, '2024-06-22', 112000.0, 10),
('B', 5, '2024-06-24', 195000.0, 1),
('C', 5, '2024-06-29', 89000.0, 2),
('C', 6, '2024-06-15', 155000, 2 );

select * from facturas;

insert into ventas (letra, numero, codigo, cantidad) values
('B', 1, '200', 2),
('C', 1, '102', 3),
('B', 2, '104', 1),
('C', 2, '202', 6),
('B', 3, '201', 7),
('C', 3, '103', 4),
('B', 4, '201', 9),
('C', 4, '101', 1),
('B', 5, '100', 1),
('C', 5, '104', 1);

select * from ventas;