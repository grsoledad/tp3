-- Active: 1717630911809@@127.0.0.1@3306@agenda
drop database if exists bazar;
create database bazar;
use bazar;
create table clientes(
    codigo int auto_increment,
    nombre  varchar(50) not null,
    apellido varchar(50) not null,
    cuit varchar (13) not null,
    direccion varchar (100),
    primary key (codigo)
);
create table articulos(
	codigo int auto_increment primary key,
    nombre varchar(50) not null,
    precio double not null,
    stock int not null
);






