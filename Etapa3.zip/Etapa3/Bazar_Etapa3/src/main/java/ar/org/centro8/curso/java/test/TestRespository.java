package ar.org.centro8.curso.java.test;


import ar.org.centro8.curso.java.entities.Articulo;
import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.entities.Venta;
import ar.org.centro8.curso.java.enums.Letra;
import ar.org.centro8.curso.java.repositories.ClienteRepository;
import ar.org.centro8.curso.java.repositories.FacturaRepository;
import ar.org.centro8.curso.java.repositories.VentaRepository;
import ar.org.centro8.curso.java.repositories.ArticuloRepository;

public class TestRespository {
    public static void main(String[] args) {
        ClienteRepository clienteRepository = new ClienteRepository();
        System.out.println(" -- Test Cliente Repository --");
        System.out.println(" -- Método .save() --");

        Cliente cliente= new Cliente(
                                        0,
                                        "Alexis",
                                        "Cuevas", 
                                        "5555555", 
                                        "1111111", 
                                    "AlexisCu@gmail.com");                   
        clienteRepository.save(cliente);
        System.out.println(cliente);                 
                                
        System.out.println(" --Método .getById() --");
        System.out.println(clienteRepository.getById(7)); 

        System.out.println("-- Método .remove() --"); 
        clienteRepository.remove(clienteRepository.getById(3));   
        
        System.out.println(" -- Método .getAll() --");
        clienteRepository.getAll().forEach(System.out::println);

        System.out.println("-- Método getLikeApellido() --");
        clienteRepository.getLikeApellido("ez").forEach(System.out::println);
                                // 
        System.out.println("#######################################################################################");
        ArticuloRepository articuloRepository = new ArticuloRepository();
        System.out.println("-- Test Articulo Repository --");  
        System.out.println("-- Método .save()--");           
        
        Articulo articulo= new Articulo(106, "mate de calabaza", 44);
        articuloRepository.save(articulo);
        System.out.println(articulo);
        
        System.out.println("-- Método .remove() --"); 
        articuloRepository.remove(articuloRepository.getById(203));   
         
        System.out.println(" -- Método .getAll() --");
        articuloRepository.getAll().forEach(System.out::println);  
        
        System.out.println(" --Método .getById() --");
        System.out.println(articuloRepository.getById(105)); 

        System.out.println("-- Método getLikeProducto() --");
        articuloRepository.getLikeProducto("car").forEach(System.out::println);
   
   
        System.out.println("#######################################################################################");
        FacturaRepository facturaRepository = new FacturaRepository();
        System.out.println("-- Test Factura Repository --");  
        System.out.println("-- Método .save()--");           

        Factura fc = new Factura(Letra.C, 6, "01/07/2024", 45000, 4 );
        facturaRepository.save(fc);
        System.out.println(fc);
        
        System.out.println("-- Método .remove() --"); 
        facturaRepository.remove(fc);
   

        System.out.println(" -- Método .getAll() --");
        facturaRepository.getAll().forEach(System.out::println);

        System.out.println(" --Método .getById() --");
        facturaRepository.getById(2).forEach(System.out::println);

        System.out.println("-- Método getLikeFecha() --");
        facturaRepository.getLikeFecha("2024-06-06").forEach(System.out::println);

        System.out.println("#######################################################################################");
        VentaRepository ventaRepository = new VentaRepository();
        System.out.println("-- Test Venta Repository --");  
        System.out.println("-- Método .save()--");           
        Venta venta = new Venta(Letra.A, 1, 104, 1);
        ventaRepository.save(venta);
        System.out.println(venta);

               
        System.out.println("-- Método .remove() --"); 
        ventaRepository.remove(venta);

        System.out.println(" -- Método .getAll() --");
        ventaRepository.getAll().forEach(System.out::println);

        System.out.println(" --Método .getById() --");
        System.out.println(ventaRepository.getByCodigo(201));
        
        System.out.println("-- Método getLikeCodigo) --");                
        ventaRepository.getLikeCodigo(201).forEach(System.out::println);
        
    }

       
        
    
}
