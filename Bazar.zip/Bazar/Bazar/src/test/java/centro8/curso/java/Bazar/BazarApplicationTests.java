package centro8.curso.java.Bazar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BazarApplicationTests {

	@Test
	void contextLoads() {
	}

}
