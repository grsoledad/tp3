package ar.org.centro8.curso.java.entities;

import ar.org.centro8.curso.java.enums.Letra;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor


public class Venta {
    private Letra letra;
    private int numero;
    private int codigo;
    private int cantidad;
}
