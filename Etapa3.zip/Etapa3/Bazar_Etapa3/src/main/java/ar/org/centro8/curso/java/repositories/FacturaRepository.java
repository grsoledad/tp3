package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Factura;
import ar.org.centro8.curso.java.enums.Letra;

public class FacturaRepository {

    private Connection conn = Connector.getConnection();
    public void save(Factura factura){
    if (factura == null) return;
    try (PreparedStatement ps = conn.prepareStatement("insert into facturas (letra, numero, fecha, monto, id_cliente) values (?,?,?,?,?)",
            PreparedStatement.RETURN_GENERATED_KEYS)) {
        ps.setString(1, factura.getLetra().toString());
        ps.setInt(2, factura.getNumero());
        ps.setString(3, factura.getFecha());
        ps.setDouble(4, factura.getMonto());
        ps.setInt(5, factura.getId_cliente());
        ps.execute();
        ResultSet rs = ps.getGeneratedKeys();
        if (rs.next())
            factura.setId_cliente((rs.getInt(1)));
        
    } catch (Exception e) {
        System.out.println(e);
    }
}
    
public void remove(Factura factura){
    if(factura == null) return;
    try (PreparedStatement ps=conn.prepareStatement(
        "delete from facturas where letra=? and numero=?")){
         ps.setString(1, factura.getLetra().toString());
         ps.setInt(2, factura.getNumero());
         ps.execute();
    } catch (Exception e){
        System.out.println(e);
    }
}
                            
public List<Factura> getAll() {
    List<Factura> list= new ArrayList();
    try (ResultSet rs = conn
            .createStatement()
            .executeQuery("select * from facturas")){
        while (rs.next()) {
            list.add(new Factura(
                Letra.valueOf(rs.getString("letra")),
                rs.getInt("numero"),
                rs.getString("fecha"),
                rs.getDouble("monto"),
                rs.getInt("id_cliente")));
                           
       }
    } catch (Exception e) {
        System.out.println(e);
    }    
    return list;
    
}
    
public List<Factura> getById(int id) {
    if(id == 0)
    return new ArrayList();
    return getAll().stream()
                   .filter(factura->factura.getId_cliente() == id)
                   .toList();
}
public List<Factura>getLikeFecha(String fecha){
    if(fecha==null) return new ArrayList();
    return getAll()
                    .stream()
                    .filter(factura->factura
                                        .getFecha()
                                        .contains(fecha))
                    .toList();
}
    
}
