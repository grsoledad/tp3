package centro8.java.tp3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp3SoledadGonzalezApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp3SoledadGonzalezApplication.class, args);
	}

}
