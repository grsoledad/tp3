-- Active: 1718231563151@@127.0.0.1@3306@bazar
drop database if exists bazar;
create database bazar;
use bazar;
drop table if exists clientes;
drop table if exists articulos;
drop table if exists facturas;
drop table if exists ventas;
create table clientes(
	id_cliente int auto_increment,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    dni char (8) not null,
    tel_celular varchar(10),
    email varchar(50),
    primary key (id_cliente)
);
create table articulos(
    codigo int primary key,
    producto varchar(100) not null,
    stock int not null
);
create table facturas(
    letra char(1),
    numero int,
    fecha date not null,
    monto double not null,
    id_cliente int,
    primary key (letra,numero,id_cliente)
);
create table ventas(
    letra char (1),
    numero int,
    codigo int,
    cantidad int not null,
    primary key (letra,numero,codigo)
);
alter table facturas
    add constraint FK__facturas_clientes
    foreign key(id_cliente)
    references clientes(id_cliente);
alter table ventas
    add constraint FK_ventas_facturas
    foreign key(letra,numero)
    references facturas(letra,numero);
alter table ventas
    add constraint FK_ventas_articulos
    foreign key(codigo)
    references articulos (codigo);