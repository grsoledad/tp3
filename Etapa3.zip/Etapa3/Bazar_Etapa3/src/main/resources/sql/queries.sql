-- Active: 1718231563151@@127.0.0.1@3306@bazar
-- cantidad de clientes que tiene el negocio
select count(*) cantidad_clientes from clientes;

-- cuantos clientes tienen un email registrado, ordenado por apellido, nombre
select  apellido,nombre, email
from clientes where email is not null group by apellido,nombre, email order by apellido,nombre;

-- listar los clientes cuyo apellido termine con z

select * from clientes where apellido like '%z';

-- listar la cantidad de facturas que hubo hecha por fecha de facturacion
select fecha,count(*) total_facturas from facturas group by fecha;

-- listar que clientes (id_cliente, nombre, apellido) compraron pochocleras
select 	distinct c.id_cliente, c.nombre, c.apellido
from 	clientes c 
join 	facturas f
on		c.id_cliente=f.id_cliente
join	ventas v
on 		v.letra=f.letra and v.numero=f.numero
join	articulos a
on 		a.codigo=v.codigo
where 	producto = 'pochoclera';

--Obtener el monto total de ventas para cada cliente.
SELECT c.nombre, c.apellido, SUM(f.monto) AS total_ventas
FROM clientes c
LEFT JOIN facturas f ON c.id_cliente = f.id_cliente
GROUP BY c.id_cliente, c.nombre, c.apellido;

--Obtener el número de compras realizadas por cada cliente.
SELECT c.nombre, c.apellido, COUNT(*) AS numero_ventas
FROM clientes c
JOIN facturas f ON c.id_cliente = f.id_cliente
JOIN ventas v ON f.letra = v.letra AND f.numero = v.numero
GROUP BY c.id_cliente, c.nombre, c.apellido;

-- informar cuantas unidades se vendieron de cada articulo
select articulos.producto,
sum(ventas.cantidad) unidades_vendidas 
from articulos
join ventas on articulos.codigo=ventas.codigo
group by articulos.producto;

-- listar los clientes a los que no se les haya hecho alguna factura
select * from clientes where id_cliente not in (select id_cliente from facturas);

-- Obtener el nombre del producto y el stock disponible de los artículos que tienen un stock inferior a 10.
SELECT a.producto, a.stock
FROM articulos a
WHERE a.stock > 80;